#ifndef TEST_H
#define TEST_H

void correrTestsStack();
void correrTestsMap();
void correrTestsNetwork();

#endif